package com.example.sib.finalproject.interfaces;

/**
 * Created by Rameen Barish on 4/29/2017.
 */

public interface MainScreenInteraction {
    void changeFragment(String fragment_name);
}