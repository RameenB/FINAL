# FINALPT2

Very similar project
https://github.com/shubhamvadhera/friend-locator-android
